from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
import os
import requests
from openai import OpenAI
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configuración de logging
logging.basicConfig(
  level=logging.INFO,
  format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
  handlers=[
      logging.FileHandler("openai_service.log"),
      logging.StreamHandler()
  ]
)
logger = logging.getLogger("openai_service")

app = Flask(__name__)
CORS(app)

# Configurar OpenAI
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
  logger.error("No se ha configurado la clave de API de OpenAI")
  # Usar una clave de API de respaldo para desarrollo
  api_key = "sk-test-key-for-development"

# Crear cliente de OpenAI
client = OpenAI(api_key=api_key)

# URL del servicio de autenticación
AUTH_SERVICE_URL = os.environ.get("AUTH_SERVICE_URL", "http://auth_service:5050")

def verify_api_key(api_key):
  """Verifica la validez de la API key con el servicio de autenticación."""
  # Para desarrollo, aceptar cualquier API key
  return True
  
  # En producción, descomentar esto:
  # try:
  #     response = requests.post(
  #         f"{AUTH_SERVICE_URL}/auth/verify",
  #         json={"api_key": api_key}
  #     )
  #     return response.status_code == 200 and response.json().get("valid", False)
  # except Exception as e:
  #     logger.error(f"Error al verificar API key: {str(e)}")
  #     return False

@app.route('/health', methods=['GET'])
def health():
  """Endpoint para verificar la salud del servicio."""
  return jsonify({"status": "up", "openai_configured": bool(api_key)}), 200

def generate_text_internal(prompt, max_tokens=1000, temperature=0.7, model="gpt-3.5-turbo"):
  """Función interna para generar texto con OpenAI."""
  try:
      # Generar texto con OpenAI
      response = client.chat.completions.create(
          model=model,
          messages=[
              {"role": "system", "content": "Eres un astrólogo experto que escribe cartas astrales detalladas y personalizadas."},
              {"role": "user", "content": prompt}
          ],
          max_tokens=max_tokens,
          temperature=temperature
      )
      
      # Extraer el texto generado
      generated_text = response.choices[0].message.content
      
      logger.info(f"Texto generado exitosamente: {len(generated_text)} caracteres")
      return {"text": generated_text}
  
  except Exception as e:
      logger.error(f"Error al generar texto con OpenAI: {str(e)}")
      import traceback
      logger.error(f"Traceback: {traceback.format_exc()}")
      
      # Para desarrollo, devolver un texto de ejemplo
      return {"text": f"Texto de ejemplo para el prompt: {prompt[:50]}..."}

@app.route('/generate', methods=['POST'])
def generate_text():
  """Endpoint para generar texto con OpenAI."""
  # Verificar API key
  api_key = request.headers.get('X-API-Key')
  if not api_key and not verify_api_key(api_key):
      logger.warning(f"Intento de acceso con API key inválida: {api_key}")
      return jsonify({"error": "API key inválida o faltante"}), 401

  # Obtener datos de la solicitud
  data = request.get_json()
  prompt = data.get('prompt')
  max_tokens = data.get('max_tokens', 1000)
  temperature = data.get('temperature', 0.7)
  model = data.get('model', 'gpt-3.5-turbo')
  
  # Validar datos requeridos
  if not prompt:
      return jsonify({"error": "Falta el prompt"}), 400

  try:
      result = generate_text_internal(prompt, max_tokens, temperature, model)
      return jsonify(result)
  
  except Exception as e:
      return jsonify({"error": f"Error al generar texto: {str(e)}"}), 500

@app.route('/openai', methods=['POST'])
def openai_endpoint():
  """Endpoint alternativo para generar texto con OpenAI."""
  return generate_text()

if __name__ == "__main__":
  app.run(debug=False, host="0.0.0.0", port=5010)

